import math

def number(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + " must be a finite number")
    if value < 0 or (positive and value == 0):
        raise ValueError(name + " is outside its allowed range")
    return float(value)

def calculate(inputs):
    defaults = {
        "prepared_material_cost_usd_per_l": 100.0,
        "cycle_time_hours": 8.0,
        "target_production_kg_per_day": 0.1,
        "operating_days_per_year": 330.0,
        "regeneration_cost_usd_per_l_cycle": 0.1,
        "electricity_kwh_per_l_cycle": 0.02,
        "electricity_price_usd_per_kwh": 0.12,
        "labor_hours_per_day": 1.0,
        "labor_rate_usd_per_hour": 35.0,
        "equipment_cost_usd": 10000.0,
        "equipment_life_years": 10.0,
        "discount_rate": 0.08,
        "maintenance_fraction_per_year": 0.03
    }
    for key in inputs:
        if key not in defaults and key not in ["collected_output_values", "useful_lifetime_values"]:
            raise ValueError("Unknown input: " + key)
    x = {}
    for key in defaults:
        x[key] = number(inputs.get(key, defaults[key]), key, key in [
            "cycle_time_hours", "target_production_kg_per_day",
            "operating_days_per_year", "equipment_life_years"])
    if x["operating_days_per_year"] > 366 or x["discount_rate"] > 1 or x["maintenance_fraction_per_year"] > 1:
        raise ValueError("Days must be at most 366; rate and maintenance fraction at most 1")
    outputs = inputs.get("collected_output_values", [0.00025, 0.0005, 0.001])
    lifetimes = inputs.get("useful_lifetime_values", [50, 100, 200])
    if not isinstance(outputs, list) or not isinstance(lifetimes, list):
        raise ValueError("Scenario axes must be lists")
    if not 1 <= len(outputs) <= 30 or not 1 <= len(lifetimes) <= 30:
        raise ValueError("Each axis must contain 1 to 30 values")
    qs = [number(v, "collected output", True) for v in outputs]
    ns = [number(v, "useful lifetime", True) for v in lifetimes]
    r = x["discount_rate"]
    years = x["equipment_life_years"]
    # CRF = r / (1 - (1+r)^(-years)); zero-rate limit = 1/years.
    crf = 1.0 / years if r == 0 else r / (-math.expm1(-years * math.log1p(r)))
    annual_kg = x["target_production_kg_per_day"] * x["operating_days_per_year"]
    labor = x["labor_hours_per_day"] * x["labor_rate_usd_per_hour"] * x["operating_days_per_year"] / annual_kg
    capital = x["equipment_cost_usd"] * crf / annual_kg
    maintenance = x["equipment_cost_usd"] * x["maintenance_fraction_per_year"] / annual_kg
    cycles_per_day = 24.0 / x["cycle_time_hours"]
    rows = []
    costs = []
    for qi in range(len(qs)):
        q = qs[qi]
        for ni in range(len(ns)):
            n = ns[ni]
            material = x["prepared_material_cost_usd_per_l"] / n / q
            regeneration = x["regeneration_cost_usd_per_l_cycle"] / q
            electricity = x["electricity_kwh_per_l_cycle"] * x["electricity_price_usd_per_kwh"] / q
            total = material + regeneration + electricity + labor + capital + maintenance
            volume = x["target_production_kg_per_day"] / (q * cycles_per_day)
            row = {
                "collected_output_kg_per_l_cycle": q,
                "useful_lifetime_cycles": n,
                "material_cost_usd_per_kg": material,
                "regeneration_cost_usd_per_kg": regeneration,
                "electricity_cost_usd_per_kg": electricity,
                "labor_cost_usd_per_kg": labor,
                "annualized_equipment_cost_usd_per_kg": capital,
                "maintenance_cost_usd_per_kg": maintenance,
                "cost_usd_per_kg": total,
                "annual_cost_usd": total * annual_kg,
                "required_material_volume_l": volume,
                "initial_material_inventory_cost_usd": volume * x["prepared_material_cost_usd_per_l"]
            }
            for key in row:
                if not math.isfinite(row[key]):
                    raise ValueError("Scenario exceeds finite numerical range")
            rows.append(row)
            costs.append(total)
    return {
        "rows": rows,
        "scenario_count": len(rows),
        "annual_collected_target_kg": annual_kg,
        "capital_recovery_factor": crf,
        "fixed_cost_usd_per_kg": labor + capital + maintenance,
        "minimum_cost_usd_per_kg": min(costs),
        "maximum_cost_usd_per_kg": max(costs),
        "sum_scenario_costs_usd_per_kg": sum(costs),
        "interpretation": "Conditional scenarios, not measurements or confidence intervals. Fixed production; inventory resizes linearly. Purity, recovery, feed feasibility and scale-up are not evaluated."
    }
