import math

def calculate(inputs):
    keys = ["material_usd_per_l", "useful_cycles", "regeneration_usd_per_l_cycle", "collected_target_kg_per_l_cycle", "annual_fixed_cost_usd", "annual_collected_target_kg"]
    positive = ["useful_cycles", "collected_target_kg_per_l_cycle", "annual_collected_target_kg"]
    for key in keys:
        value = inputs[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Inputs must be numeric")
        if not math.isfinite(value) or value < 0:
            raise ValueError("Inputs must be finite and nonnegative")
        if key in positive and value <= 0:
            raise ValueError("Cycle life and collected quantities must be positive")
    material = inputs["material_usd_per_l"] / inputs["useful_cycles"] / inputs["collected_target_kg_per_l_cycle"]
    regeneration = inputs["regeneration_usd_per_l_cycle"] / inputs["collected_target_kg_per_l_cycle"]
    fixed = inputs["annual_fixed_cost_usd"] / inputs["annual_collected_target_kg"]
    total = material + regeneration + fixed
    if not math.isfinite(total):
        raise ValueError("Result exceeds finite numerical range")
    return {"material_cost_usd_per_kg": material, "regeneration_cost_usd_per_kg": regeneration, "fixed_cost_usd_per_kg": fixed, "cost_usd_per_kg": total}
